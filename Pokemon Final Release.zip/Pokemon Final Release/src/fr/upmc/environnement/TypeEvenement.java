package fr.upmc.environnement;

public enum TypeEvenement {
	SEISME,
	TSUNAMI,
	ERUPTION,
	SECHERESSE,
	FEU_DE_FORET
}
