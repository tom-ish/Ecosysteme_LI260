package fr.upmc.environnement;

public enum MapType {
	VILLE, GROTTE;
}
